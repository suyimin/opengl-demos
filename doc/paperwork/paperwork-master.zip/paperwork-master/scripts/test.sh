#!/usr/bin/env bash

echo "String output of test.sh"
