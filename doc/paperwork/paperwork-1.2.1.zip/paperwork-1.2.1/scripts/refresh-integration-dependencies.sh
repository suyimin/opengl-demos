#!/usr/bin/env bash

cp paperwork-plugin/src/main/groovy/* buildSrc/src/main/groovy/ -r