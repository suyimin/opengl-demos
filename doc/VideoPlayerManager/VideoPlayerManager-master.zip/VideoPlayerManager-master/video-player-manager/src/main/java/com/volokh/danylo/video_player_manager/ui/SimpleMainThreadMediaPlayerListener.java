package com.volokh.danylo.video_player_manager.ui;

/**
 * You can use this class and override only those methods you need
 * Created by danylo.volokh on 1/11/2016.
 */
public class SimpleMainThreadMediaPlayerListener implements MediaPlayerWrapper.MainThreadMediaPlayerListener {
    @Override
    public void onVideoSizeChangedMainThread(int width, int height) {

    }

    @Override
    public void onVideoPreparedMainThread() {

    }

    @Override
    public void onVideoCompletionMainThread() {

    }

    @Override
    public void onErrorMainThread(int what, int extra) {

    }

    @Override
    public void onBufferingUpdateMainThread(int percent) {

    }

    @Override
    public void onVideoStoppedMainThread() {

    }
}
