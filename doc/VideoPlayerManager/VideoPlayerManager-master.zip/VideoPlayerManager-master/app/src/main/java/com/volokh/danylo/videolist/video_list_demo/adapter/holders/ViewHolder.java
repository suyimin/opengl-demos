package com.volokh.danylo.videolist.video_list_demo.adapter.holders;

public interface ViewHolder {
    void play();
}
