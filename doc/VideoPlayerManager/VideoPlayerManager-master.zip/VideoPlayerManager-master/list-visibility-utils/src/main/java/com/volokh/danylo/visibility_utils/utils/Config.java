package com.volokh.danylo.visibility_utils.utils;

/**
 * Created by danylo.volokh on 06.01.2016.
 */
public class Config {

    public static final boolean SHOW_LOGS = true;

}
