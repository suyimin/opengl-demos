package com.kot32.kshareviewactivitylibrary.actions;

/**
 * Created by kot32 on 16/1/22.
 */
public interface KShareViewActivityAction {

    void onAnimatorStart();

    void onAnimatorEnd();
}
