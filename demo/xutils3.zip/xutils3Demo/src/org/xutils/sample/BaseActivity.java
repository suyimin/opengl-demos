package org.xutils.sample;

import org.xutils.x;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

/**
 * Created by wyouflf on 15/11/4.
 */
public class BaseActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        x.view().inject(this);
    }
}
