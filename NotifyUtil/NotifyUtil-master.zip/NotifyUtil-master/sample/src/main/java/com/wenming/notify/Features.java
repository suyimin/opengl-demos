package com.wenming.notify;

/**
 * Created by wenmingvs on 2016/1/14.
 */
public class Features {

    public static boolean showProfile = true;

}
